﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SSL
{
    public partial class CultureGenerale : Form
    {
        private Jouer RefToJouer;

        public CultureGenerale(Jouer frm)
        {
            RefToJouer = frm;
            InitializeComponent();
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            RefToJouer.Show();
            this.Close();
        }
    }
}
